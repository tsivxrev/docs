cat /proc/meminfo | sed -n '1,5p'
